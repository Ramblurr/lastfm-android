package androidx;

import android.util.Log;

public class LogX {
	final private static String TAG = "Last.fm";

	public static void d(String s) {
		Log.d(TAG, s);
	}

	public static void i(String s) {
		Log.i(TAG, s);
	}

	public static void e(String s) {
		Log.e(TAG, s);
	}

	public static void e(Throwable e) {
		Log.e(TAG, "", e);
	}

	public static void e(String msg, Throwable e) {
		Log.e(TAG, msg, e);
	}
}
