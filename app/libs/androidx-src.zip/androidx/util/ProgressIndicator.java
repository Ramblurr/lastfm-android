package androidx.util;

public interface ProgressIndicator {
	void showProgressIndicator();
	void hideProgressIndicator();
}
