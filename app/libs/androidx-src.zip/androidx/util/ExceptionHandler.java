package androidx.util;

public interface ExceptionHandler {
  public void onFailure(Throwable t);
}
