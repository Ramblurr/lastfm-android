// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.api.impl;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.SortedSet;
import java.util.TreeSet;

import fm.last.api.*;

/**
 * An implementation of LastFmServer
 *
 * @author Mike Jennings
 */
final class LastFmServerImpl implements LastFmServer {
  private String api_key;
  private String api_sig;
  private String baseUrl;

  LastFmServerImpl(String baseUrl, String api_key, String api_sig) {
    this.baseUrl = baseUrl;
    this.api_key = api_key;
    this.api_sig = api_sig;
  }

  private Map<String, String> createParams(String method) {
    Map<String, String> params = new HashMap<String, String>();
    params.put("method", method);
    params.put("api_key", api_key);
    return params;    
  }

  private Map<String, String> createParamsWithSig(String method) {
    Map<String, String> params = new HashMap<String, String>();
    params.put("method", method);
    params.put("api_key", api_key);
    params.put("api_sig", api_sig);
    return params;
  }

  /**
   * "sign" parameters in the way that last.fm expects.
   *
   * See: http://www.last.fm/api/authspec#8
   * 
   * @param params
   */
  private void signParams(Map<String, String> params) {
    StringBuilder sb = new StringBuilder();
    SortedSet<String> keySet = new TreeSet<String>(params.keySet());
    for (String key : keySet) {
      sb.append(key).append(params.get(key));
    }
    sb.append(api_sig);
    String signature = sb.toString();
    String api_sig = MD5.getInstance().hash(signature);
    // now we pad to 32 chars if we need to:
    while( 32 - api_sig.length() > 0 )
      api_sig = "0" + api_sig;

    params.put("api_sig", api_sig);
  }


  /**
   * See: http://www.last.fm/api/show?service=119
   * @param artist
   * @return
   * @throws IOException
   */
  public Artist[] getSimilarArtists(String artist, String limit) throws IOException {
    Map<String, String> params = createParams("artist.getsimilar");
    if (artist != null) {
      params.put("artist", artist);
    }
    if (limit != null) {
      params.put("limit", limit);
    }
    return ArtistFunctions.getSimilarArtists(baseUrl, params);
  }

  public Friends getFriends(String user, String recenttracks, String limit) throws IOException {
    Map<String, String> params = createParams("user.getFriends");
    if (user != null) {
      params.put("user", user);
    }
    if (recenttracks != null) {
      params.put("recenttracks", recenttracks);
    }
    if (limit != null) {
      params.put("limit", limit);
    }
    return FriendFunctions.getFriends(baseUrl, params);
  }

  public Track getTrackInfo(String artist, String track, String mbid) throws IOException {
    Map<String, String> params = createParams("track.getInfo");
    if (artist != null) {
      params.put("artist", artist);
    }
    if (track != null) {
      params.put("track", track);
    }
    if (mbid != null) {
      params.put("mbid", mbid);
    }
    return TrackFunctions.getTrackInfo(baseUrl, params);
  }

  public Session getMobileSession(String username, String authToken) throws IOException {
    Map<String, String> params = createParamsWithSig("auth.getMobileSession");
    if (username != null) {
      params.put("username", username);
    }
    if (authToken != null) {
      params.put("authToken", authToken);
    }
    return AuthFunctions.getMobileSession(baseUrl, params);
  }

  public Station tuneToSimilarArtist(String station, String sk) throws IOException {
    Map<String, String> params = createParams("radio.tune");
    if (station != null) {
      params.put("station", station);
    }
    if (sk != null) {
      params.put("sk", sk);
    }
    signParams(params);
    return RadioFunctions.tuneToSimilarArtist(baseUrl, params);
  }

  public RadioPlayList getRadioPlayList(String sk) throws IOException {
    Map<String, String> params = createParams("radio.getRadioPlayList");
    if (sk != null) {
      params.put("sk", sk);
    }
    signParams(params);
    return RadioFunctions.getPlaylist(baseUrl, params);
  }
}
