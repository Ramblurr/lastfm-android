// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.api.impl;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

import fm.last.util.UrlUtil;
import fm.last.util.XMLUtil;
import fm.last.api.LastFmServer;
import fm.last.api.Artist;
import fm.last.api.Friends;
import fm.last.api.Track;
import fm.last.api.Session;

/**
 * An implementation of LastFmServer
 *
 * @author Mike Jennings
 */
final class LastFmServerImpl implements LastFmServer {
  private String api_key;
  private String api_sig;
  private String baseUrl;

  LastFmServerImpl(String baseUrl, String api_key, String api_sig) {
    this.baseUrl = baseUrl;
    this.api_key = api_key;
    this.api_sig = api_sig;
  }

  private Map<String, String> createParams(String method) {
    Map<String, String> params = new HashMap<String, String>();
    params.put("method", method);
    params.put("api_key", api_key);
    return params;    
  }

  private Map<String, String> createParamsWithSig(String method) {
    Map<String, String> params = new HashMap<String, String>();
    params.put("method", method);
    params.put("api_key", api_key);
    params.put("api_sig", api_sig);
    return params;
  }

  /**
   * See: http://www.last.fm/api/show?service=119
   * @param artist
   * @return
   * @throws IOException
   */
  public Artist[] getSimilarArtists(String artist, String limit) throws IOException {
    Map<String, String> params = createParams("artist.getsimilar");
    if (artist != null) {
      params.put("artist", artist);
    }
    if (limit != null) {
      params.put("limit", limit);
    }
    return ArtistFunctions.getSimilarArtists(baseUrl, params);
  }

  public Friends getFriends(String user, String recenttracks, String limit) throws IOException {
    Map<String, String> params = createParams("user.getFriends");
    if (user != null) {
      params.put("user", user);
    }
    if (recenttracks != null) {
      params.put("recenttracks", recenttracks);
    }
    if (limit != null) {
      params.put("limit", limit);
    }
    return FriendFunctions.getFriends(baseUrl, params);
  }

  public Track getTrackInfo(String artist, String track, String mbid) throws IOException {
    Map<String, String> params = createParams("track.getInfo");
    if (artist != null) {
      params.put("artist", artist);
    }
    if (track != null) {
      params.put("track", track);
    }
    if (mbid != null) {
      params.put("mbid", mbid);
    }
    return TrackFunctions.getTrackInfo(baseUrl, params);
  }

  public Session getMobileSession(String username, String authToken) throws IOException {
    Map<String, String> params = createParamsWithSig("auth.getMobileSession");
    if (username != null) {
      params.put("username", username);
    }
    if (authToken != null) {
      params.put("authToken", authToken);
    }
    return AuthFunctions.getMobileSession(baseUrl, params);
  }
}
