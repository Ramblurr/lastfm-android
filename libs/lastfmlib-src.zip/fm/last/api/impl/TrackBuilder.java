// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.api.impl;

import org.w3c.dom.Node;

import java.util.List;

import fm.last.api.Artist;
import fm.last.api.ImageUrl;
import fm.last.api.Track;
import fm.last.api.Album;
import fm.last.xml.XMLBuilder;

/**
 * @author Mike Jennings
 */
public class TrackBuilder extends XMLBuilder<Track> {
  private ArtistBuilder artistBuilder = new ArtistBuilder();
  private AlbumBuilder albumBuilder = new AlbumBuilder();

  public Track build(Node trackNode) {
    node = trackNode;
    String id = getText("id");
    String name = getText("name");
    String mbid = getText("mbid");
    String url = getText("url");
    String duration = getText("duration");
    String streamable = getText("streamable");
    String listeners = getText("listeners");
    String playcount = getText("playcount");
    Node artistNode = getChildNode("artist");
    Artist artist = artistBuilder.build(artistNode);
    Node albumNode = getChildNode("album");
    Album album = albumBuilder.build(albumNode);
    return new Track(id, name, mbid, url, duration, streamable, listeners, playcount, artist, album);
  }
}