// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.api;

/**
 * Holds global information relevant to lastfm
 *
 * @author Mike Jennings
 */
public class LastFmGlobal {
  private static LastFmGlobal singleton;
  private static final String API_KEY = "3ef388dabf4bba6c58daf6a3fafa509c";
  private static final String API_SECRET = "fa17924450ff9754a830d4b43bd2f3c7";
  private static final String XMLRPC_ROOT_URL = "http://ws.audioscrobbler.com/2.0/";

  public static LastFmGlobal getInstance() {
    if (singleton == null) {
      singleton = new LastFmGlobal();
    }
    return singleton;
  }

  private LastFmGlobal() {
  }

  public String getApiKey() {
    return API_KEY;
  }

  public String getApiSecret() {
    return API_SECRET;
  }

  public String getRootUrlForXmlRpc() {
    return XMLRPC_ROOT_URL;
  }
}
