// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.util;

import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.HashMap;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;

/**
 * A collection of utility methods to manipulate URLs.
 *
 * @author Mike Jennings
 */
public class UrlUtil {
  private UrlUtil() {
  }

  public static String doGet(URL url) throws IOException {
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    BufferedReader reader = null;
    try {
      int rc = conn.getResponseCode();
      if (rc != 200) {
        throw new IOException("code " + rc + " '" + conn.getResponseMessage() + "'");
      }
      reader = new BufferedReader(new InputStreamReader(conn.getInputStream()), 512);
      return toString(reader);
    } finally {
      if (reader != null) {
        reader.close();
      }
    }
  }

  public static String doGet(String baseurl, Map<String, String> params) throws IOException {
    if (params.isEmpty()) {
      return doGet(new URL(baseurl));
    }
    StringBuilder sb = null;
    for (String key : params.keySet()) {
      String value = params.get(key);
      if (sb == null) {
        sb = new StringBuilder(baseurl);
        sb.append("?").append(escape(key)).append('=').append(escape(value));
      } else {
        sb.append("&").append(escape(key)).append('=').append(escape(value));
      }
    }
    URL url = new URL(sb.toString());
    return doGet(url);
  }

  private static String escape(String s) {
    return URLEncoder.encode(s);
  }

  public static String getXML(URL url) throws IOException {
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
      return toString(reader);
    } finally {
      if (reader != null) {
        reader.close();
      }
    }
  }

  private static String toString(BufferedReader reader) throws IOException {
    StringBuilder sb = new StringBuilder();
    String line;
    while ( (line = reader.readLine()) != null) {
      sb.append(line).append('\n');
    }
    return sb.toString();
  }

  private static String readString(BufferedReader reader) throws IOException {
    String line;
    StringBuilder sb = new StringBuilder();
    while ( (line = reader.readLine()) != null) {
        sb.append(line);
    }
    return sb.toString();
  }


  private static Map<String, String> getParams(BufferedReader reader) throws IOException {
    Map<String, String> params = new HashMap<String, String>();
    String line;
    int eq;
    while ( (line = reader.readLine()) != null) {
      eq = line.indexOf('=');
      if (eq > 0) {
        String key = line.substring(0, eq);
        String value = line.substring(eq + 1);
        params.put(key, value);
      }
    }
    return params;
  }

}

