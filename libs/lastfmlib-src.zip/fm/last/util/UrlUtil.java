// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last.util;

import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;

/**
 * A collection of utility methods to manipulate URLs.
 *
 * @author Mike Jennings
 */
public class UrlUtil {
  private UrlUtil() {
  }


  private static void copy(InputStream in, OutputStream out) throws IOException {
    byte[] buf = new byte[512];
    int bytesRead = 1;
    while (bytesRead > 0) {
      bytesRead = in.read(buf);
      if (bytesRead > 0) {
        out.write(buf, 0, bytesRead);
      }
    }
  }

  public static String doPost(URL url, InputStream stuffToPost) throws IOException {
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("POST");
    conn.setDoOutput(true);
    OutputStream ostr = null;
    try {
      ostr = conn.getOutputStream();
      copy(stuffToPost, ostr);
    } finally {
      ostr.close();
    }

    conn.connect();
    BufferedReader reader = null;
    try {
      int rc = conn.getResponseCode();
      if (rc != 200) {
        throw new IOException("code " + rc + " '" + conn.getResponseMessage() + "'");
      }
      reader = new BufferedReader(new InputStreamReader(conn.getInputStream()), 512);
      String response = toString(reader);
      return response;
    } finally {
      if (reader != null) {
        reader.close();
      }
    }
  }

  public static String doPost(URL url, String input) throws IOException {
    return doPost(url, new ByteArrayInputStream(input.getBytes()));
  }
  

  public static String doGet(URL url) throws IOException {
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    BufferedReader reader = null;
    try {
      int rc = conn.getResponseCode();
      if (rc != 200) {
        throw new IOException("code " + rc + " '" + conn.getResponseMessage() + "'");
      }
      reader = new BufferedReader(new InputStreamReader(conn.getInputStream()), 512);
      return toString(reader);
    } finally {
      if (reader != null) {
        reader.close();
      }
    }
  }

  private static String buildUrl(String baseurl, Map<String, String> params) throws IOException {
    if (params.isEmpty()) {
      return baseurl;
    } else {
      return baseurl + "?" + buildQuery(params);
    }
  }

  public static String buildQuery(Map<String, String> params) {
    StringBuilder sb = null;
    for (String key : params.keySet()) {
      String value = params.get(key);
      if (sb == null) {
        sb = new StringBuilder();
        sb.append(escape(key)).append('=').append(escape(value));
      } else {
        sb.append("&").append(escape(key)).append('=').append(escape(value));
      }
    }
    return sb.toString();

  }

  public static String doGet(String baseurl, Map<String, String> params) throws IOException {
    return doGet(new URL(buildUrl(baseurl, params)));
  }

  private static String escape(String s) {
    return URLEncoder.encode(s);
  }

  public static String getXML(URL url) throws IOException {
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("GET");
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
      return toString(reader);
    } finally {
      if (reader != null) {
        reader.close();
      }
    }
  }

  private static String toString(BufferedReader reader) throws IOException {
    StringBuilder sb = new StringBuilder();
    String line;
    while ( (line = reader.readLine()) != null) {
      sb.append(line).append('\n');
    }
    return sb.toString();
  }

  private static String readString(BufferedReader reader) throws IOException {
    String line;
    StringBuilder sb = new StringBuilder();
    while ( (line = reader.readLine()) != null) {
        sb.append(line);
    }
    return sb.toString();
  }


  private static Map<String, String> getParams(BufferedReader reader) throws IOException {
    Map<String, String> params = new HashMap<String, String>();
    String line;
    int eq;
    while ( (line = reader.readLine()) != null) {
      eq = line.indexOf('=');
      if (eq > 0) {
        String key = line.substring(0, eq);
        String value = line.substring(eq + 1);
        params.put(key, value);
      }
    }
    return params;
  }

}

