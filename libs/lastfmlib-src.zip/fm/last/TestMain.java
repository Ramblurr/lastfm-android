// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last;

import java.net.URL;
import java.util.Map;
import java.util.HashMap;

import fm.last.api.*;
import fm.last.util.UrlUtil;

/**
 * Please delete this
 *
 * See: 
 *
 */
public class TestMain {
public static void main(String[] args) throws Exception {
  LastFmGlobal g = LastFmGlobal.getInstance();
  String apiKey = g.getApiKey();
  String apiSecret = g.getApiSecret();
  String rootUrl = g.getRootUrlForXmlRpc();

/*
  String urls = g.getRootUrlForXmlRpc() + "?method=artist.getsimilar&artist=Radiohead&api_key=" + apiKey;
  URL url = new URL(urls);
  String response = UrlUtil.doGet(url);


  Map<String, String> params = new HashMap<String, String>();
  params.put("method", "artist.getsimilar");
  params.put("artist", "Radiohead");
  params.put("api_key", apiKey);
  String response = UrlUtil.doGet(rootUrl, params);
  System.out.println("Response=" + response);
*/
  LastFmServer server = LastFmServerFactory.getServer(rootUrl, apiKey, apiSecret);
  Artist[] artists = server.getSimilarArtists("radiohead", null);
  for (Artist artist : artists) {
    System.out.println("artist name=" + artist.getName());
  }

  Friends friends = server.getFriends("mcjennings", null, null);
  System.out.println("friends = " + friends);

  String toPost = "<methodCall>\n" +
      " <methodName>user.gettoptags</methodName>\n" +
      " <params>\n" +
      "  <param>\n" +
      "   <value>\n" +
      "    <struct>\n" +
      "     <member>\n" +
      "      <name>user</name>\n" +
      "      <value>\n" +
      "       <string>joanofarctan</string>\n" +
      "      </value>\n" +
      "     </member>\n" +
      "     <member>\n" +
      "      <name>api_key</name>\n" +
      "      <value>\n" +
      "       <string>3ef388dabf4bba6c58daf6a3fafa509c</string>\n" +
      "      </value>\n" +
      "     </member>\n" +
      "    </struct>\n" +
      "   </value>\n" +
      "  </param>\n" +
      " </params>\n" +
      "</methodCall>";

  URL url = new URL("http://ws.audioscrobbler.com/2.0/");
  //url.getQuery()

//  String response = UrlUtil.doPost(url, toPost);
//  System.out.println(response);

  Track track = server.getTrackInfo("Radiohead", "Paranoid Android", null);
  System.out.println("track = " + track);
  String u = "AndroidTest";
  String p = "foo";
  MD5 md5 = MD5.getInstance();
  String authToken = md5.hash(u + md5.hash(p));
  Session session = server.getMobileSession(u, authToken);
  System.out.println("session=" + session.getKey());
  Station station = server.tuneToSimilarArtist("lastfm://artist/radiohead/similarartists", session.getKey());
  System.out.println("station.name=" + station.getName() + " url=" + station.getUrl());
  }
}
