// Copyright 2008 Google Inc. All Rights Reserved.

package fm.last;

import java.net.URL;
import java.util.Map;
import java.util.HashMap;

import fm.last.api.*;
import fm.last.util.UrlUtil;

/**
 * Please delete this
 *
 * See: 
 *
 */
public class TestMain {
public static void main(String[] args) throws Exception {
  LastFmGlobal g = LastFmGlobal.getInstance();
  String apiKey = g.getApiKey();
  String rootUrl = g.getRootUrlForXmlRpc();

/*
  String urls = g.getRootUrlForXmlRpc() + "?method=artist.getsimilar&artist=Radiohead&api_key=" + apiKey;
  URL url = new URL(urls);
  String response = UrlUtil.doGet(url);


  Map<String, String> params = new HashMap<String, String>();
  params.put("method", "artist.getsimilar");
  params.put("artist", "Radiohead");
  params.put("api_key", apiKey);
  String response = UrlUtil.doGet(rootUrl, params);
  System.out.println("Response=" + response);
*/
  LastFmServer server = LastFmServerFactory.getServer(rootUrl, apiKey);
  Artist[] artists = server.getSimilarArtists("radiohead", null);
  for (Artist artist : artists) {
    System.out.println("artist name=" + artist.getName());
  }

  Friends friends = server.getFriends("mcjennings", null, null);
  System.out.println("friends = " + friends);

  Track track = server.getTrackInfo("Radiohead", "Paranoid Android", null);
  System.out.println("track = " + track);
  }
}
