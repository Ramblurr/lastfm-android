rm mjlastfm.zip
zip -r -X mjlastfm.zip *

